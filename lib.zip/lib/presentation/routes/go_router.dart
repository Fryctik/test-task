import 'package:go_router/go_router.dart';
import 'package:test/presentation/pages/auth/identification/view/identification.dart';
import 'package:test/presentation/pages/auth/onboarding/view/onboard.dart';
import 'package:test/presentation/pages/auth/otp/view/otp_veregication.dart';
import 'package:test/presentation/pages/edit_profiel/editing_profile.dart';
import 'package:test/presentation/screens/authentication_screens/editing_profile_screen/editing_profile.dart';

import '../pages/main/view/main_page.dart';
import '../pages/splash/view/splash_page.dart';
import '../screens/authentication_screens/identification_screen/view/identification.dart';
import '../screens/authentication_screens/onboard_screen/view/onboard.dart';
import '../screens/authentication_screens/otp_verification_screen/view/otp_veregication.dart';

final router = GoRouter(routes: [
  GoRoute(
    name: '/',
    path: '/',
    builder: (context, state) => const SplashPage(),
  ),
  GoRoute(
      name: '/main',
      path: '/main',
      builder: (context, state) => const MainPage(),
      ),
  GoRoute(
      name: '/onboarding',
      path: '/onboarding',
      builder: (context, state) => const OnboardScreen(),
  ),
  GoRoute(
    name: '/identification',
    path: '/identification',
    builder: (context, state) => const IdentificationScreen(),
  ),
  GoRoute(
    name: '/otp_verefication',
    path: '/otp_verefication/:number',
    builder: (context, state) =>
        OtpVerificationScreen(number: state.pathParameters['number'] ?? ''),
  ),
  GoRoute(
    name: '/editing_profile',
    path: '/editing_profile',
    builder: (context, state) => const EditingProfileScreen(),
  ),
],
);