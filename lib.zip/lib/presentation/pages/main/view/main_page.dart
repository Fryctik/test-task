import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:test/config/contstants/app_colors.dart';
import 'package:test/presentation/widgets/add_minus_buttons.dart';
import 'package:test/presentation/widgets/custom_cart.dart';
import 'package:test/presentation/widgets/custom_check.dart';
import 'package:test/presentation/widgets/custom_common_button.dart';
import 'package:test/presentation/widgets/custom_data.dart';
import 'package:test/presentation/widgets/custom_menu_button.dart';
import 'package:test/presentation/widgets/custom_num_textfield.dart';

import 'package:test/presentation/widgets/custom_serice_card.dart';
import '../../../widgets/custom_back_button.dart';
import '../../../widgets/custom_bottom_navigation.dart';
import '../../../widgets/custom_button_up.dart';

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {

  // final FocusNode focusNode = FocusNode();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return   Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("COMPONENTS"),
      ),

      bottomNavigationBar: CustomNavigationBar(),
      body: SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Center(
          child: Column(


              children: [
                CommonWidgetButton(text: "ВОЙТИ", colorButton: AppColors.main,textColor: AppColors.white,)
                ,SizedBox(height: 10.h,),
                CustomButtonUp(colorButton: AppColors.main,),
                SizedBox(height: 10.h,),
                // CustomNumTextfield(
                //     focusNode: focusNode
                // ),
                SizedBox(height: 10.h,),
                CustomMenuButton(serviceStatus: ServiceStatus.inactive,),
                SizedBox(height: 10.h,)
               ,
                  CustomData(),
                  SizedBox(height: 10,),

                InputEmailWidget(theme: theme,),
                SizedBox(height: 10,),
                InputNameWidget(theme:theme),
                SizedBox(height: 10.h,),
                SelectionCityWidget(theme: theme,),
                SizedBox(height: 10.h,),
                SelectionGenderWidget(theme:theme),
                SizedBox(height: 10.h,),
                CustomDropdown(isError: false,),
                SizedBox(height: 10.h,),
                CustomBackButton(
                  onBack: () {  },
                ),
                SizedBox(height: 20,),
                AddMinusButtons(),
                SizedBox(height: 10,),
                CustomCart(title: "10 пакет л", description: "150 шт, без ручек",price: 299,),
                SizedBox(height: 10,),

                ServiceCard(),

              ],
          ),
        ),
      ),
    );
  }
}
