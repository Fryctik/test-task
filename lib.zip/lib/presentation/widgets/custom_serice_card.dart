import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:test/config/contstants/app_colors.dart';
import 'package:test/config/contstants/app_text_styles.dart';
import 'package:test/generated/assets.dart';
import 'package:test/themes/themes.dart';

class ServiceCard extends StatefulWidget {
  const ServiceCard({super.key, required, required this.description, required this.price, required this.kilogram, required this.type, required this.image});
  final String type;
  final String description;
  final String price;
  final int kilogram;
  final String image;

  @override
  State<ServiceCard> createState() => _ServiceCardState();
}

class _ServiceCardState extends State<ServiceCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 150,
      width: 350.w,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24), color: AppColors.white,
      boxShadow: [
        BoxShadow(
          color: AppColors.shade1, // Shadow color
          spreadRadius: 3, // Spread radius
          blurRadius: 3, // Blur radius
          offset: Offset(0, 1), // Offset in x and y direction
        ),
      ]
      ),
      child: Row(
        children: [
          Image.asset(widget.image),
          Expanded(
            child: Container(
              padding: EdgeInsets.only(top: 16, bottom: 16,right: 20),
              width: 202.w,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                   widget.type,
                    style: AppTextStyles.body16GeologicaSemiBold,
                  ),
                  SizedBox(height: 5,),
                  Text(
                   widget.description,
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyles.body14GeologicaLight
                        .copyWith(color: AppColors.shade3),
                  ),
                  SizedBox(height: 12,),
                  SizedBox(
                    height: 25,
                    width: 202.w,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Text(
                          "от ${widget.price}₽",
                          style: AppTextStyles.body16GeologicaSemiBold,
                        ),
                        Container(
                          height: 25,
                          width: 81.w,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(
                                10,
                              ),
                              color: AppColors.accent),
                          child: Center(
                              child: Text(
                            "до ${widget.kilogram} кг",
                            style: AppTextStyles.body14GeologicaMedium
                                .copyWith(color: AppColors.white),
                          )),
                        )
                      ],
                    ),
                  )
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
