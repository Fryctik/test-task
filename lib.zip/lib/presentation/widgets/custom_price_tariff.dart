import 'package:flutter/material.dart';
import 'package:test/config/contstants/app_colors.dart';
import 'package:test/config/contstants/app_text_styles.dart';

class CustomPriceTariff extends StatefulWidget {
  const CustomPriceTariff({super.key, required this.available, required this.price});
  final bool available;
  final num? price;

  @override
  State<CustomPriceTariff> createState() => _CustomPriceTariffState();
}

class _CustomPriceTariffState extends State<CustomPriceTariff> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height:70,
      width:  272,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text("Вывоз курьером",style:  AppTextStyles.body16GeologicaLight,maxLines: 1,),
          Text("до 20 кг",style: AppTextStyles.body16GeologicaLight.copyWith(color: AppColors.shade3),),
          Text( widget.available == true ? "${widget.price}₽" : "Недоступно в вашем городе",style: AppTextStyles.body16GeologicaSemiBold.copyWith(color: widget.available == true ? AppColors.main: AppColors.shade2 ),maxLines: 1,),

        ],
      ),
    );
  }
}
