abstract class AppStrings {
  static const uslugi = "Услуги";
}

final List<String> citiesList = ['Мытищи', 'Москва', 'Королев'];